import type { Plugin } from '@vuepress/core';
export declare type CozePluginOptions = Record<never, never>;
export declare const CozePluginOptions: Plugin<CozePluginOptions>;
