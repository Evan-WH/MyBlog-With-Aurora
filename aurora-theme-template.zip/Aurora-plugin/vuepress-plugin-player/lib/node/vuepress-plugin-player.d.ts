import type { Plugin } from '@vuepress/core';
export declare type PlayerPluginOptions = Record<never, never>;
export declare const PlayerPluginOptions: Plugin<PlayerPluginOptions>;
