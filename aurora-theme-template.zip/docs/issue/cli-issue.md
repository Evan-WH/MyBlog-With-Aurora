# 脚手架安装报错

## **不是内部或外部命令**

你如果安装好`vuepress-theme-cli`之后，运行`aurora demo-blog`，控制台报下面这个错误

```sh
'aurora' 不是内部或外部命令，也不是可运行的程序
或批处理文件。
```



1. 在cmd命令行窗口中，运行`npm root -g`查看全局安装路径

   ![image-20211127110241162](https://ooszy.cco.vin/img/blog-note/image-20211127110241162.png?x-oss-process=style/pictureProcess1)

2. 进入

   ![image-20211127110342527](https://ooszy.cco.vin/img/blog-note/image-20211127110342527.png?x-oss-process=style/pictureProcess1)

![image-20211127110725839](https://ooszy.cco.vin/img/blog-note/image-20211127110725839.png?x-oss-process=style/pictureProcess1)



现在就可以了

