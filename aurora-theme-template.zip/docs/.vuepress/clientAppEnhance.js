import { defineClientAppEnhance } from '@vuepress/client'
//import UseBlog from "./components/UseBlog.vue";
export default defineClientAppEnhance(({ app, router, siteData }) => {
    //你可以在这里注册全局组件，通过下面这种方式
    //app.component("UseBlog",UseBlog)
})