# vuepress静态文件

在`docs/.vuepress/public`目录下的文件，都是静态文件，你可以在此文件夹中存放图片，歌曲等等静态文件，
加入该public文件夹中有一个`avatar.jpg`图片，那么你可以直接在浏览器中通过`localhost:[8080]/avatar.jpg`进行访问
加入有`docs/.vuepress/public/song/1.mp3`，那么你可以通过`localhost:[8080]/song/1.mp3`进行访问，关于静态文件
详细请看[vuepress静态文件](https://v2.vuepress.vuejs.org/zh/guide/assets.html)